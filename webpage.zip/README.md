# Genshin Impact Team Calculator
A web-based calculator for ascension items in complete teams.
